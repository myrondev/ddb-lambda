import json
import boto3

def lambda_handler(event, context):
    # Create a DynamoDB client
    dynamodb = boto3.client('dynamodb')

    try:
        # Extract the bucket and object key from the S3 event
        s3_event = event['Records'][0]['s3']
        bucket_name = s3_event['bucket']['name']
        object_key = s3_event['object']['key']

        # Read the JSON file from S3
        s3 = boto3.client('s3')
        response = s3.get_object(Bucket=bucket_name, Key=object_key)
        file_content = response['Body'].read().decode('utf-8')

        # Parse the JSON content
        items = json.loads(file_content)

        # Insert each item into DynamoDB
        for item in items:
            response = dynamodb.put_item(
                TableName='ddb-lambda-table',
                Item={
                    'id': {'S': item['id']},
                    'name': {'S': item['name']},
                    'surname': {'S': item['surname']},
                    'birthdate': {'S': item['birthdate']},
                    'address': {'S': item['address']},
                    'car': {'M': {
                        'make': {'S': item['car']['make']},
                        'model': {'S': item['car']['model']},
                        'year': {'N': str(item['car']['year'])},
                        'color': {'S': item['car']['color']},
                        'plate': {'S': item['car']['plate']},
                        'mileage': {'N': str(item['car']['mileage'])},
                        'fuelType': {'S': item['car']['fuelType']},
                        'transmission': {'S': item['car']['transmission']}
                    }},
                    'fee': {'N': str(item['fee'])}
                }
            )
            print("Data inserted successfully:", response)

        # Return a response
        return {
            'statusCode': 200,
            'body': json.dumps('Data inserted successfully')
        }
    except Exception as e:
        print("Error inserting data:", e)
        # Return an error response
        return {
            'statusCode': 500,
            'body': json.dumps('Error inserting data')
        }
